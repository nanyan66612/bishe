from django.db import models
from django.contrib.auth.models import User
from questions.models import Question


class Submit(models.Model):
    """代码提交记录"""
    RESULT_CHOICES = [
        ('AC', '答案正确'),
        ('WA', '答案错误'),
        ('CE', '编译错误'),
        ('RE', '运行时错误'),
        ('TLE', '超时'),
        ('RJ', '待人工审核'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='submits')
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='submits')
    code = models.TextField(verbose_name='提交的代码')
    result = models.CharField(max_length=10, choices=RESULT_CHOICES, verbose_name='评测结果')
    error_message = models.TextField(default='', blank=True, verbose_name='错误信息')
    execution_time = models.FloatField(default=0, verbose_name='执行时间(秒)')
    memory_used = models.IntegerField(default=0, verbose_name='内存使用(KB)')
    needs_review = models.BooleanField(default=False, verbose_name='需要人工审核')
    reviewed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='reviewed_submits', verbose_name='审核教师')
    review_result = models.CharField(max_length=10, choices=[('AC', '正确'), ('WA', '错误')], null=True, blank=True, verbose_name='人工审核结果')
    review_comment = models.TextField(default='', blank=True, verbose_name='审核备注')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = '提交记录'
        verbose_name_plural = '提交记录'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} - {self.question.title} - {self.result}"


class WrongQuestion(models.Model):
    """错题本"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='wrong_questions')
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='wrong_records')
    wrong_count = models.IntegerField(default=1, verbose_name='错误次数')
    last_wrong_at = models.DateTimeField(auto_now=True, verbose_name='最后错误时间')
    is_mastered = models.BooleanField(default=False, verbose_name='已掌握')
    mastered_at = models.DateTimeField(null=True, blank=True, verbose_name='掌握时间')
    
    class Meta:
        verbose_name = '错题本'
        verbose_name_plural = '错题本'
        unique_together = ('user', 'question')
        ordering = ['-wrong_count']

    def __str__(self):
        return f"{self.user.username} - {self.question.title}"


class PracticeStat(models.Model):
    """练习统计"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='practice_stat')
    total_submits = models.IntegerField(default=0, verbose_name='总提交次数')
    ac_count = models.IntegerField(default=0, verbose_name='正确次数')
    total_questions = models.IntegerField(default=0, verbose_name='完成题目数')
    streak_days = models.IntegerField(default=0, verbose_name='连续打卡天数')
    last_practice_at = models.DateTimeField(null=True, blank=True, verbose_name='最后练习时间')
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = '练习统计'
        verbose_name_plural = '练习统计'

    @property
    def ac_rate(self):
        """正确率"""
        if self.total_submits == 0:
            return 0
        return round(self.ac_count / self.total_submits * 100, 1)

    def __str__(self):
        return f"{self.user.username} - 正确率{self.ac_rate}%"
