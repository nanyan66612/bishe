from django.contrib import admin
from .models import Submit, WrongQuestion, PracticeStat


@admin.register(Submit)
class SubmitAdmin(admin.ModelAdmin):
    list_display = ['user', 'question', 'result', 'execution_time', 'created_at']
    list_filter = ['result', 'created_at']
    search_fields = ['user__username', 'question__title']
    date_hierarchy = 'created_at'


@admin.register(WrongQuestion)
class WrongQuestionAdmin(admin.ModelAdmin):
    list_display = ['user', 'question', 'wrong_count', 'is_mastered', 'last_wrong_at']
    list_filter = ['is_mastered']
    search_fields = ['user__username', 'question__title']


@admin.register(PracticeStat)
class PracticeStatAdmin(admin.ModelAdmin):
    list_display = ['user', 'total_submits', 'ac_count', 'ac_rate', 'total_questions', 'streak_days']
    readonly_fields = ['ac_rate']
