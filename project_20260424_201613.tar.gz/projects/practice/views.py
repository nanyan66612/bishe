from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Count, Q
from datetime import datetime, timedelta
from .models import Submit, WrongQuestion, PracticeStat
from questions.models import Question
from judge.judger import run_c_code


@login_required
def practice_list(request):
    """题目列表（分类刷题）"""
    # 获取筛选参数
    category = request.GET.get('category', '')
    difficulty = request.GET.get('difficulty', '')
    status = request.GET.get('status', '')  # all, solved, unsolved
    
    qs = Question.objects.filter(is_active=True)
    
    if category:
        qs = qs.filter(category=category)
    if difficulty:
        qs = qs.filter(difficulty=difficulty)
    
    # 标记已解决的题目
    solved_ids = Submit.objects.filter(
        user=request.user, 
        result='AC'
    ).values_list('question_id', flat=True).distinct()
    
    # 分类统计
    categories = Question.CATEGORY_CHOICES
    difficulties = Question.DIFFICULTY_CHOICES
    
    # 知识点统计
    category_stats = []
    for cat_value, cat_label in categories:
        total = Question.objects.filter(category=cat_value, is_active=True).count()
        solved = Question.objects.filter(
            category=cat_value, 
            is_active=True,
            id__in=solved_ids
        ).count()
        category_stats.append({
            'value': cat_value,
            'label': cat_label,
            'total': total,
            'solved': solved,
            'rate': round(solved / total * 100, 1) if total > 0 else 0
        })
    
    # 分页
    paginator = Paginator(qs, 20)
    page = request.GET.get('page', 1)
    questions = paginator.get_page(page)
    
    context = {
        'questions': questions,
        'categories': categories,
        'difficulties': difficulties,
        'category_stats': category_stats,
        'solved_ids': list(solved_ids),
        'filter_category': category,
        'filter_difficulty': difficulty,
        'filter_status': status,
    }
    return render(request, 'practice/practice_list.html', context)


@login_required
def practice_detail(request, qid):
    """做题页面"""
    q = get_object_or_404(Question, id=qid, is_active=True)
    
    # 获取用户的最佳提交结果
    best_result = Submit.objects.filter(
        user=request.user, 
        question=q, 
        result='AC'
    ).first()
    
    # 获取用户对该题的提交记录
    recent_submits = Submit.objects.filter(
        user=request.user, 
        question=q
    ).order_by('-created_at')[:5]
    
    if request.method == 'POST':
        code = request.POST.get('code', '')
        if not code.strip():
            messages.error(request, "代码不能为空")
            return render(request, 'practice/editor.html', {
                'q': q, 
                'best_result': best_result,
                'recent_submits': recent_submits
            })
        
        # 运行代码评测
        result, error_msg, exec_time = run_c_code_safe(code, q)
        
        # 保存提交记录
        submit = Submit.objects.create(
            user=request.user,
            question=q,
            code=code,
            result=result,
            error_message=error_msg,
            execution_time=exec_time
        )
        
        # 更新错题记录
        if result != 'AC':
            wrong, created = WrongQuestion.objects.get_or_create(
                user=request.user,
                question=q
            )
            if not created:
                wrong.wrong_count += 1
                wrong.save()
        else:
            # 如果AC了，从错题本移除或标记为已掌握
            WrongQuestion.objects.filter(user=request.user, question=q).update(
                is_mastered=True,
                mastered_at=datetime.now()
            )
        
        # 更新统计
        update_practice_stat(request.user, result)
        
        messages.success(request, f"评测完成：{submit.get_result_display()}")
        return redirect('practice:practice_result', submit_id=submit.id)
    
    return render(request, 'practice/editor.html', {
        'q': q, 
        'best_result': best_result,
        'recent_submits': recent_submits
    })


@login_required
def practice_result(request, submit_id):
    """提交结果页面"""
    submit = get_object_or_404(Submit, id=submit_id, user=request.user)
    return render(request, 'practice/result.html', {'submit': submit})


def run_c_code_safe(code, question):
    """安全的代码运行函数"""
    import subprocess
    import tempfile
    import os
    import stat
    import shutil
    
    result = 'RE'
    error_msg = ''
    exec_time = 0
    
    try:
        # 获取测试输入（支持多组测试用例）
        test_inputs = [x.strip() for x in question.test_input.strip().split('---')] if question.test_input.strip() else []
        test_outputs = [x.strip() for x in question.test_output.strip().split('---')] if question.test_output.strip() else []
        
        # 如果没有配置测试用例，使用单组
        if not test_inputs:
            test_inputs = ['']
        if not test_outputs:
            test_outputs = ['']
        
        # 创建临时目录
        tmpdir = tempfile.mkdtemp()
        c_file = os.path.join(tmpdir, 'code.c')
        exe_file = os.path.join(tmpdir, 'code')
        
        with open(c_file, 'w') as f:
            f.write(code)
        
        # 编译
        cp = subprocess.run(
            ['gcc', c_file, '-o', exe_file, '-O2'],
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if cp.returncode != 0:
            # 清理并返回编译错误
            shutil.rmtree(tmpdir, ignore_errors=True)
            return 'CE', cp.stderr[:500], 0
        
        # 确保可执行权限
        os.chmod(exe_file, os.stat(exe_file).st_mode | stat.S_IEXEC)
        
        # 运行每个测试用例
        for i, (ipt, opt) in enumerate(zip(test_inputs, test_outputs)):
            rp = subprocess.run(
                [exe_file],
                input=ipt + '\n' if ipt else '',
                capture_output=True,
                text=True,
                timeout=3,
                cwd=tmpdir  # 设置工作目录
            )
            
            if rp.returncode != 0:
                shutil.rmtree(tmpdir, ignore_errors=True)
                return 'RE', f'Runtime Error (exit code {rp.returncode}): {rp.stderr[:100]}', 0
            
            # 规范化输出进行比较（去除多余空白字符）
            actual = ' '.join(rp.stdout.strip().split())
            expected = ' '.join(opt.split())
            
            if actual != expected:
                shutil.rmtree(tmpdir, ignore_errors=True)
                return 'WA', f'第{i+1}组测试用例输出错误\n期望: {expected}\n实际: {actual}', 0
        
        result = 'AC'
        
    except subprocess.TimeoutExpired:
        result = 'TLE'
        error_msg = 'Time Limit Exceeded'
    except FileNotFoundError as e:
        result = 'RE'
        error_msg = f'File not found: {str(e)[:100]}'
    except Exception as e:
        result = 'RE'
        error_msg = str(e)[:200]
    finally:
        # 清理临时文件
        try:
            shutil.rmtree(tmpdir, ignore_errors=True)
        except:
            pass
    
    return result, error_msg, exec_time


def update_practice_stat(user, result):
    """更新用户练习统计"""
    stat, _ = PracticeStat.objects.get_or_create(user=user)
    stat.total_submits += 1
    
    if result == 'AC':
        stat.ac_count += 1
    
    # 更新完成题目数
    stat.total_questions = Submit.objects.filter(
        user=user, 
        result='AC'
    ).values('question').distinct().count()
    
    # 更新最后练习时间
    stat.last_practice_at = datetime.now()
    
    stat.save()


@login_required
def wrong_list(request):
    """错题本"""
    wrongs = WrongQuestion.objects.filter(user=request.user).select_related('question')
    
    # 分类筛选
    filter_type = request.GET.get('type', 'all')
    if filter_type == 'unmastered':
        wrongs = wrongs.filter(is_mastered=False)
    elif filter_type == 'mastered':
        wrongs = wrongs.filter(is_mastered=True)
    
    return render(request, 'practice/wrong_list.html', {
        'wrongs': wrongs,
        'filter_type': filter_type
    })


@login_required
def my_stats(request):
    """我的统计"""
    stat, _ = PracticeStat.objects.get_or_create(user=request.user)
    
    # 最近的提交记录
    recent_submits = Submit.objects.filter(
        user=request.user
    ).select_related('question').order_by('-created_at')[:10]
    
    # 分类完成情况
    categories = Question.CATEGORY_CHOICES
    category_progress = []
    for cat_value, cat_label in categories:
        total = Question.objects.filter(category=cat_value, is_active=True).count()
        if total > 0:
            solved = Question.objects.filter(
                category=cat_value,
                is_active=True,
                submits__user=request.user,
                submits__result='AC'
            ).distinct().count()
            category_progress.append({
                'label': cat_label,
                'total': total,
                'solved': solved,
                'rate': round(solved / total * 100, 1)
            })
    
    # 每日提交统计（最近7天）
    today = datetime.now().date()
    daily_stats = []
    daily_labels = []
    daily_data = []
    for i in range(6, -1, -1):
        day = today - timedelta(days=i)
        count = Submit.objects.filter(
            user=request.user,
            created_at__date=day
        ).count()
        daily_stats.append({
            'date': day.strftime('%m/%d'),
            'count': count
        })
        daily_labels.append(day.strftime('%m/%d'))
        daily_data.append(count)
    
    return render(request, 'practice/my_stats.html', {
        'stat': stat,
        'recent_submits': recent_submits,
        'category_progress': category_progress,
        'daily_stats': daily_stats,
        'daily_labels': daily_labels,
        'daily_data': daily_data
    })


@login_required
def submission_list(request):
    """我的提交记录"""
    submits = Submit.objects.filter(
        user=request.user
    ).select_related('question').order_by('-created_at')
    
    # 分页
    paginator = Paginator(submits, 20)
    page = request.GET.get('page', 1)
    submissions = paginator.get_page(page)
    
    return render(request, 'practice/submission_list.html', {
        'submissions': submissions
    })
