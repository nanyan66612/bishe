from django.urls import path
from . import views

app_name = 'practice'

urlpatterns = [
    path('list/', views.practice_list, name='practice_list'),
    path('<int:qid>/', views.practice_detail, name='practice_detail'),
    path('submit/<int:submit_id>/', views.practice_result, name='practice_result'),
    path('wrong/', views.wrong_list, name='wrong_list'),
    path('stats/', views.my_stats, name='my_stats'),
    path('submissions/', views.submission_list, name='submission_list'),
]
