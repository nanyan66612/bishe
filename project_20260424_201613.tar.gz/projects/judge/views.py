from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Count, Avg, Q
from django.core.paginator import Paginator
from practice.models import Submit, WrongQuestion, PracticeStat
from questions.models import Question
from users.models import UserProfile
from classroom.models import Classroom, ClassMember
from datetime import datetime, timedelta


def is_teacher(user):
    """检查是否为教师"""
    if not user.is_authenticated:
        return False
    try:
        return user.profile.role == 'teacher'
    except:
        return False


def teacher_required(view_func):
    """教师权限装饰器"""
    def wrapper(request, *args, **kwargs):
        if not is_teacher(request.user):
            from django.shortcuts import redirect
            from django.contrib import messages
            messages.error(request, "您没有教师权限")
            return redirect('student_dashboard')
        return view_func(request, *args, **kwargs)
    return wrapper


@login_required
@teacher_required
def teacher_stats(request):
    """学情分析页面"""
    # 获取教师创建的班级
    teacher_classrooms = Classroom.objects.filter(teacher=request.user)
    classroom_ids = teacher_classrooms.values_list('id', flat=True)
    
    # 获取本班学生
    my_student_ids = ClassMember.objects.filter(
        classroom_id__in=classroom_ids
    ).values_list('student_id', flat=True).distinct()
    
    # 如果没有班级，显示提示
    has_classroom = teacher_classrooms.exists()
    
    # 总体统计（仅本班学生）
    total_students = len(my_student_ids)
    total_questions = Question.objects.filter(is_active=True).count()
    
    # 只统计本班学生的提交
    if my_student_ids:
        total_submits = Submit.objects.filter(user_id__in=my_student_ids).count()
        stats = PracticeStat.objects.filter(user__profile__role='student', user_id__in=my_student_ids)
    else:
        total_submits = 0
        stats = PracticeStat.objects.none()
    
    # 计算平均正确率
    avg_ac_rate = 0
    if stats.exists():
        avg_ac_rate = round(sum(s.ac_rate for s in stats) / stats.count(), 1)
    
    # 题目难度分布
    difficulty_stats = []
    for diff, label in Question.DIFFICULTY_CHOICES:
        count = Question.objects.filter(difficulty=diff, is_active=True).count()
        difficulty_stats.append({'label': label, 'count': count})
    
    # 知识点分布（仅本班学生）
    category_stats = []
    for cat, label in Question.CATEGORY_CHOICES:
        total = Question.objects.filter(category=cat, is_active=True).count()
        avg_rate = 0
        if my_student_ids:
            submits = Submit.objects.filter(question__category=cat, user_id__in=my_student_ids)
            if submits.exists():
                ac_count = submits.filter(result='AC').count()
                avg_rate = round(ac_count / submits.count() * 100, 1)
        category_stats.append({
            'label': label,
            'total': total,
            'avg_rate': avg_rate
        })
    
    # 学生排名（按正确次数，仅本班学生）
    student_ranking = []
    for stat in stats.select_related('user').order_by('-ac_count')[:10]:
        student_ranking.append({
            'username': stat.user.username,
            'user_id': stat.user.id,
            'total_submits': stat.total_submits,
            'ac_count': stat.ac_count,
            'ac_rate': stat.ac_rate,
            'total_questions': stat.total_questions
        })
    
    # 难题榜（通过率最低的题目）
    hard_questions = []
    for q in Question.objects.filter(is_active=True):
        if my_student_ids:
            submits = Submit.objects.filter(question=q, user_id__in=my_student_ids)
        else:
            submits = Submit.objects.none()
        if submits.exists():
            ac_rate = round(submits.filter(result='AC').count() / submits.count() * 100, 1)
            hard_questions.append({
                'id': q.id,
                'title': q.title,
                'category': q.get_category_display,
                'difficulty': q.difficulty,
                'submit_count': submits.count(),
                'ac_rate': ac_rate
            })
    hard_questions.sort(key=lambda x: x['ac_rate'])
    hard_questions = hard_questions[:5]
    
    # 每日提交趋势（仅本班学生）
    today = datetime.now().date()
    daily_trend = []
    for i in range(6, -1, -1):
        day = today - timedelta(days=i)
        if my_student_ids:
            count = Submit.objects.filter(created_at__date=day, user_id__in=my_student_ids).count()
        else:
            count = 0
        daily_trend.append({
            'date': day.strftime('%m/%d'),
            'count': count
        })
    
    context = {
        'total_students': total_students,
        'total_questions': total_questions,
        'total_submits': total_submits,
        'avg_ac_rate': avg_ac_rate,
        'difficulty_stats': difficulty_stats,
        'category_stats': category_stats,
        'student_ranking': student_ranking,
        'hard_questions': hard_questions,
        'daily_trend': daily_trend,
        'has_classroom': has_classroom,
    }
    return render(request, 'judge/teacher_stats.html', context)


@login_required
@teacher_required
def all_submissions(request):
    """所有提交记录"""
    submits = Submit.objects.select_related('user', 'question').order_by('-created_at')
    
    # 筛选
    username = request.GET.get('username', '')
    question_id = request.GET.get('question_id', '')
    result = request.GET.get('result', '')
    
    if username:
        submits = submits.filter(user__username__icontains=username)
    if question_id:
        submits = submits.filter(question_id=question_id)
    if result:
        submits = submits.filter(result=result)
    
    # 分页
    paginator = Paginator(submits, 30)
    page = request.GET.get('page', 1)
    submissions = paginator.get_page(page)
    
    return render(request, 'judge/all_submissions.html', {
        'submissions': submissions,
        'filter_username': username,
        'filter_question_id': question_id,
        'filter_result': result,
    })


@login_required
@teacher_required
def student_detail(request, user_id):
    """学生详情"""
    student = User.objects.get(id=user_id)
    submits = Submit.objects.filter(user=student).select_related('question').order_by('-created_at')[:50]
    wrong_questions = WrongQuestion.objects.filter(user=student).select_related('question')
    
    try:
        stat = PracticeStat.objects.get(user=student)
    except PracticeStat.DoesNotExist:
        stat = None
    
    # 分类统计
    category_stats = []
    for cat, label in Question.CATEGORY_CHOICES:
        total = Question.objects.filter(category=cat, is_active=True).count()
        solved = Submit.objects.filter(
            user=student,
            question__category=cat,
            result='AC'
        ).values('question').distinct().count()
        category_stats.append({
            'label': label,
            'total': total,
            'solved': solved
        })
    
    return render(request, 'judge/student_detail.html', {
        'student': student,
        'submits': submits,
        'wrong_questions': wrong_questions,
        'stat': stat,
        'category_stats': category_stats
    })


@login_required
@teacher_required
def question_stats(request, question_id):
    """题目统计"""
    question = Question.objects.get(id=question_id)
    submits = Submit.objects.filter(question=question)
    
    total_submits = submits.count()
    ac_count = submits.filter(result='AC').count()
    wa_count = submits.filter(result='WA').count()
    ce_count = submits.filter(result='CE').count()
    re_count = submits.filter(result='RE').count()
    
    ac_rate = round(ac_count / total_submits * 100, 1) if total_submits > 0 else 0
    
    # 最近提交
    recent_submits = submits.order_by('-created_at')[:10]
    
    return render(request, 'judge/question_stats.html', {
        'question': question,
        'total_submits': total_submits,
        'ac_count': ac_count,
        'wa_count': wa_count,
        'ce_count': ce_count,
        're_count': re_count,
        'ac_rate': ac_rate,
        'recent_submits': recent_submits
    })


@login_required
@teacher_required
def review_list(request):
    """待审核提交列表"""
    # 只显示本班学生的待审核提交
    teacher_classrooms = Classroom.objects.filter(teacher=request.user)
    classroom_ids = teacher_classrooms.values_list('id', flat=True)
    my_student_ids = ClassMember.objects.filter(
        classroom_id__in=classroom_ids
    ).values_list('student_id', flat=True).distinct()
    
    # 待审核的提交（CE/RE/TLE）
    submits = Submit.objects.filter(
        user_id__in=my_student_ids,
        needs_review=False,  # 默认未标记为需要审核
        result__in=['CE', 'RE', 'TLE']
    ).select_related('user', 'question').order_by('-created_at')
    
    # 手动申请审核的提交
    review_requests = Submit.objects.filter(
        user_id__in=my_student_ids,
        needs_review=True,
        review_result__isnull=True
    ).select_related('user', 'question').order_by('-created_at')
    
    paginator = Paginator(submits, 30)
    page = request.GET.get('page', 1)
    submissions = paginator.get_page(page)
    
    return render(request, 'judge/review_list.html', {
        'submissions': submissions,
        'review_requests': review_requests,
    })


@login_required
@teacher_required
def review_submit(request, submit_id):
    """审核单个提交"""
    submit = get_object_or_404(Submit, id=submit_id)
    
    # 验证是否为本班学生
    teacher_classrooms = Classroom.objects.filter(teacher=request.user)
    classroom_ids = teacher_classrooms.values_list('id', flat=True)
    my_student_ids = ClassMember.objects.filter(
        classroom_id__in=classroom_ids
    ).values_list('student_id', flat=True).distinct()
    
    if submit.user_id not in my_student_ids:
        messages.error(request, "您只能审核本班学生的提交")
        return redirect('review_list')
    
    if request.method == 'POST':
        action = request.POST.get('action', '')
        comment = request.POST.get('comment', '')
        
        submit.reviewed_by = request.user
        submit.review_comment = comment
        
        if action == 'approve':
            # 批准为正确
            submit.review_result = 'AC'
            submit.result = 'AC'
            messages.success(request, "已审核通过，正确")
        elif action == 'reject':
            # 拒绝为错误
            submit.review_result = 'WA'
            messages.success(request, "已审核，拒绝")
        
        submit.save()
        return redirect('review_list')
    
    return render(request, 'judge/review_submit.html', {'submit': submit})
