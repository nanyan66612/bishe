#!/bin/bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_DIR"

echo "[setup] Installing Django dependencies..."

# Django 项目可能没有显式的 requirements.txt，直接安装 django
if ! python -c "import django" 2>/dev/null; then
    echo "[setup] Django not found, installing..."
    pip install django
else
    echo "[setup] Django already installed"
fi

echo "[setup] Running database migrations..."
python manage.py migrate --noinput

echo "[setup] Setup completed"
