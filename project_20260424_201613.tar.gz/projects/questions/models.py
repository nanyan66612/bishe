from django.db import models


class Question(models.Model):
    """C语言编程题目"""
    DIFFICULTY_CHOICES = [
        ('easy', '简单'),
        ('medium', '中等'),
        ('hard', '困难'),
    ]
    
    CATEGORY_CHOICES = [
        ('basic', '基础语法'),
        ('condition', '条件判断'),
        ('loop', '循环结构'),
        ('array', '数组'),
        ('function', '函数'),
        ('pointer', '指针'),
        ('string', '字符串'),
        ('structure', '结构体'),
        ('file', '文件操作'),
    ]

    title = models.CharField(max_length=200, verbose_name='题目名称')
    content = models.TextField(verbose_name='题目描述')
    input_format = models.TextField(default='', verbose_name='输入格式')
    output_format = models.TextField(default='', verbose_name='输出格式')
    sample_input = models.TextField(default='', verbose_name='样例输入')
    sample_output = models.TextField(default='', verbose_name='样例输出')
    hint = models.TextField(default='', blank=True, verbose_name='提示')
    
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, verbose_name='知识点分类')
    difficulty = models.CharField(max_length=10, choices=DIFFICULTY_CHOICES, default='medium', verbose_name='难度')
    
    # 基础测试用例（兼容旧字段）
    test_input = models.TextField(default='', blank=True, verbose_name='测试输入')
    test_output = models.TextField(default='', blank=True, verbose_name='测试输出')
    
    is_active = models.BooleanField(default=True, verbose_name='是否启用')
    created_by = models.ForeignKey('users.UserProfile', on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = '编程题目'
        verbose_name_plural = '编程题目'
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    def get_difficulty_display_class(self):
        """返回难度对应的Bootstrap颜色类"""
        mapping = {'easy': 'success', 'medium': 'warning', 'hard': 'danger'}
        return mapping.get(self.difficulty, 'secondary')


class TestCase(models.Model):
    """测试用例表（支持多组测试）"""
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='test_cases')
    input_data = models.TextField(verbose_name='输入数据')
    expected_output = models.TextField(verbose_name='期望输出')
    is_sample = models.BooleanField(default=False, verbose_name='是否显示')
    order = models.IntegerField(default=0, verbose_name='排序')
    score = models.IntegerField(default=10, verbose_name='分值')

    class Meta:
        verbose_name = '测试用例'
        verbose_name_plural = '测试用例'
        ordering = ['order']

    def __str__(self):
        return f"{self.question.title} - Case {self.order + 1}"
