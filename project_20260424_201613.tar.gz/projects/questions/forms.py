from django import forms
from .models import Question, TestCase


class QuestionForm(forms.ModelForm):
    """题目表单"""
    class Meta:
        model = Question
        fields = [
            'title', 'content', 'input_format', 'output_format',
            'sample_input', 'sample_output', 'hint',
            'category', 'difficulty', 'test_input', 'test_output', 'is_active'
        ]
        widgets = {
            'content': forms.Textarea(attrs={'rows': 5, 'class': 'form-control'}),
            'input_format': forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
            'output_format': forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
            'sample_input': forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
            'sample_output': forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
            'hint': forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
            'test_input': forms.Textarea(attrs={'rows': 3, 'class': 'form-control', 'placeholder': '多组测试用例用 --- 分隔'}),
            'test_output': forms.Textarea(attrs={'rows': 3, 'class': 'form-control', 'placeholder': '多组测试用例用 --- 分隔'}),
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'category': forms.Select(attrs={'class': 'form-select'}),
            'difficulty': forms.Select(attrs={'class': 'form-select'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }


class TestCaseForm(forms.ModelForm):
    """测试用例表单"""
    class Meta:
        model = TestCase
        fields = ['input_data', 'expected_output', 'is_sample', 'order', 'score']
        widgets = {
            'input_data': forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
            'expected_output': forms.Textarea(attrs={'rows': 2, 'class': 'form-control'}),
            'is_sample': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'order': forms.NumberInput(attrs={'class': 'form-control', 'min': 0}),
            'score': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
        }
