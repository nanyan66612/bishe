from django.contrib import admin
from .models import Question, TestCase


class TestCaseInline(admin.TabularInline):
    model = TestCase
    extra = 1
    fields = ['input_data', 'expected_output', 'is_sample', 'order', 'score']


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ['title', 'category', 'difficulty', 'is_active', 'created_at']
    list_filter = ['category', 'difficulty', 'is_active']
    search_fields = ['title', 'content']
    inlines = [TestCaseInline]
    fieldsets = (
        ('基本信息', {
            'fields': ('title', 'category', 'difficulty', 'is_active')
        }),
        ('题目描述', {
            'fields': ('content', 'input_format', 'output_format', 'sample_input', 'sample_output', 'hint')
        }),
        ('测试用例（旧格式）', {
            'fields': ('test_input', 'test_output'),
            'classes': ('collapse',)
        }),
    )


@admin.register(TestCase)
class TestCaseAdmin(admin.ModelAdmin):
    list_display = ['question', 'order', 'is_sample', 'score']
    list_filter = ['is_sample']
