from django.contrib import admin
from .models import Classroom, ClassMember


@admin.register(Classroom)
class ClassroomAdmin(admin.ModelAdmin):
    list_display = ['name', 'teacher', 'invite_code', 'created_at']
    list_filter = ['created_at']
    search_fields = ['name', 'invite_code', 'teacher__username']


@admin.register(ClassMember)
class ClassMemberAdmin(admin.ModelAdmin):
    list_display = ['classroom', 'student', 'joined_at']
    list_filter = ['classroom']
    search_fields = ['classroom__name', 'student__username']
