from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('users.urls')),
    path('questions/', include('questions.urls')),
    path('practice/', include('practice.urls')),
    path('judge/', include('judge.urls')),
    path('classroom/', include('classroom.urls')),
]
