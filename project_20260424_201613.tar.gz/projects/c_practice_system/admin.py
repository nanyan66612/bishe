from django.contrib import admin
from django.contrib.admin import AdminSite

class MyAdminSite(AdminSite):
    site_header = 'C语言练习系统管理'
    site_title = '管理系统'
    index_title = '管理首页'
    
    def get_app_list(self, request):
        """去掉"查看站点"按钮"""
        app_list = super().get_app_list(request)
        return app_list

admin_site = MyAdminSite(name='myadmin')

# 注册应用到自定义 Admin 站点
admin_site.register(Question)
admin_site.register(TestCase)
admin_site.register(Submit)
admin_site.register(WrongQuestion)
admin_site.register(PracticeStat)
admin_site.register(UserProfile)
admin_site.register(TeacherCode)

# 重新注册默认 admin site 为无"查看站点"版本
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

class UserAdmin(BaseUserAdmin):
    pass

admin.site._registry = admin_site._registry
admin.site.site_header = 'C语言练习系统管理'
admin.site.site_title = '管理系统'
admin.site.index_title = '管理首页'
